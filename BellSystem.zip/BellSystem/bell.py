from playsound import playsound

playsound('Bell.wav')
