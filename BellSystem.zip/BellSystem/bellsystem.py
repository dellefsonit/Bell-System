from datetime import datetime
import time
from playsound import playsound
#import simpleaudio as sa
#import os

#Initializing bell_count, bell_time, reg_sched
bell_count = 12
reg_sched = ['09:22:00', '09:24:00','09:26:00','08:05:00','08:10:00','08:55:00','09:00:00','09:54:00','09:56:00','09:58:00','10:58:00','11:00:00','11:02:00','11:28:00','11:32:00','11:59:00','12:03:00','12:07:00','12:33:00','12:35:00','12:37:00','13:37:00','13:39:00','13:41:00','14:41:00','14:43:00','14:45:00','15:28:00','15:33:00','21:15:00','21:18:00','21:20:00']

#print(len(reg_sched))
def displayTime():
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    print("Current Time = ", current_time)

#def ringBell():


while True:
    try:
        bell_time = reg_sched[bell_count]
        now = datetime.now()
        current_time = now.strftime("%H:%M:%S")
     #   print(current_time)
        #displayTime()
        #ringBell()

        if bell_time == current_time:
            print('Bell Time =', bell_time)
            print('Current Time = ', current_time)
            print('Bell Count =', bell_count)
            print('Time matches, play sound!')
            playsound('Bell.wav')
            #wave_obj = sa.WaveObject.from_wave_file('Bell.wav')
            #play_obj = wav_obj.play()
            #play_opb.wait_done()#wait until sound has finished playing
            time.sleep(40)
            #os.remove('Bell.wav')
            
            print('Slept 40!')
            bell_count += 1
            print('Bell Count =', bell_count)

    except:
        print('All Bells Played!')
        print('Restart program to play bells for next day!')
        break;
