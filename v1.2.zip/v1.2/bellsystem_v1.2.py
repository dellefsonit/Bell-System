#Bell system program- Version 1.1
#Programmer- Dave Ellefson
#School- Eastern Allamakee CSD
#Original Build Date: 4/26/2024
#Original Version: bellsystem_v1
#Version 1.1 5/3/2024- Fixed issues with bell_count not resetting and allowing the program to go on to the next day. Issues with testing for the current bell_count to be >= len(bell_sched) - 1. Out of index error. Allows for continuing to the next iteration of the loop after resetting the bell_count to 0
#   by calling the startDay() function and passing the bell_sched and 0 for the bell_count to restart the day. Eliminated the verbose output for "Time Matches! Play sound!" Changed output so that it only displays the next bell time after the bell rings. System also prints out the next bell
#   in the schedule.

from datetime import datetime
import time
from playsound import playsound


#Main System menu
def mainmenu():
    #Initializing bell_count, bell_time, reg_sched, late_sched, early_sched, test_schedule (for testing purposes), and bell_sched (for storing the current, active schedule)
    bell_count = 0
    reg_sched = ['08:05:00','08:10:00','08:50:00','08:52:00','08:54:00','09:54:00','09:56:00','09:58:00','10:58:00','11:00:00','11:02:00','11:28:00','11:32:00','11:59:00','12:03:00','12:07:00','12:33:00','12:35:00','12:37:00','13:37:00','13:39:00','13:41:00','14:41:00','14:43:00','14:45:00','15:28:00','15:33:00']
    early_sched = ['08:05:00','08:10:00','08:45:00','08:47:00','08:49:00','09:24:00','09:26:00','09:28:00','10:03:00','10:05:00','10:07:00','10:42:00','10:44:00','10:46:00','11:21:00','11:23:00','11:25:00','11:49:00','11:53:00','12:18:00','12:22:00','12:46:00','12:48:00','12:50:00','13:28:00','13:33:00']
    late_sched = ['10:05:00','10:10:00','10:45:00','10:47:00','10:49:00','11:24:00','11:26:00','11:28:00','11:52:00','11:56:00','12:21:00','12:25:00','12:49:00','12:51:00','12:53:00','13:28:00','13:30:00','13:32:00','14:07:00','14:09:00','14:11:00','14:46:00','14:48:00','14:50:00','15:28:00','15:33:00']
    test_sched = list()
    bell_sched = list()

    while True:
        displayTime()
        print('Active schedule: ', bell_sched)
        print('Bell Count: ', bell_count)
        print('Welcome to the bell system (version 1):')
        print('''Make a selection:
                 1. Set Schedule.
                 2. Start the day.
                 3. Exit the program.''')
        menuchoice = input('>>> ')

        if menuchoice == '1':
            bell_sched, bell_count = selectSchedule(reg_sched, early_sched, late_sched, test_sched)
        elif menuchoice == '2':
            if len(bell_sched) == 0:
                print('Please select 1 from the main menu to set the schedule.')
                mainmenu()
            else:
                startDay(bell_sched, bell_count)
        else:
            print('Exiting program...')
            quit()

def selectSchedule(reg, early, late, test):
    active_sched = list()
    count = 0
    
    print('Select which schedule you would like to use:')
    print('1. Regular Schedule.')
    print('2. Early Dismissal Schedule.')
    print('3. Late Start Schedule.')

    menuchoice = input('>>> ')

    if menuchoice == '1':
        active_sched = reg
        print('Regular bell schedule set...')
    elif menuchoice == '2':
        active_sched = early
        print('Early dismissal schedule set...')
    elif menuchoice == '3':
        active_sched = late
        print('Late start schedule set...')
    else:
        print('Invalid choice!')
        mainmenu()

    menuchoice = input('Are you starting at the beginning of the day/before the first bell rings(y/n)? ')

    if menuchoice == 'y':
        count = 0
    else:
        print('Please enter a starting time:')

        x = 0

        while x < len(active_sched):
            print(x, active_sched[x])
            x += 1

        try:
            menuchoice = int(input('>>> '))
        except:
            print('Enter a number!')
            mainmenu()

        if ((menuchoice < 0) or (menuchoice > (len(active_sched) - 1))):
            print('Invalid choice!')
            count = 0
        else:
            count = menuchoice
    return active_sched, count

#Displaying Time
def displayTime():
    now = datetime.now()
    #current_time = now.strftime()
    print('Current Time = ', now)

#Starting Day
def startDay(bell_sched, bell_count):
    now = datetime.now()
    current_time = now.strftime('%H:%M:%S')
    bell_time = bell_sched[bell_count]
    print('Current Time ', current_time)
    print('Press Ctrl-C to return to the main menu')
    print('Bell Count =', bell_count)
    print('Next bell ', bell_time)
    
    try:
        while True:
            bell_time = bell_sched[bell_count]
            now = datetime.now()
            current_time = now.strftime('%H:%M:%S')
            #print('Bell Count =', bell_count)
            #print('Next bell at: ', bell_time)


            if bell_time == current_time:
                #print('Bell Time =', bell_time)
                #print('Current Time = ', current_time)
                #print('Bell Count =', bell_count)
                #print('Time matches, play sound!')
                playsound('Bell.wav')
                time.sleep(40)
                bell_count += 1
                now = datetime.now()
                current_time = now.strftime('%H:%M:%S')
                #print('Slept 40!')

                
                if bell_count >= (len(bell_sched) - 1):
                    print('All Bells Played!')
                    print('Resetting bell count for next day..')
                    bell_count == 0

                    #Calling start day and passing the bell_sched and bell_count of 0 to the function to start the next day with the same schedule
                    startDay(bell_sched, 0)
                else:
                    bell_time = bell_sched[bell_count]
                    print('Press Ctrl-C to return to the main menu')
                    print('Bell Count =', bell_count)
                    print('Next bell ', bell_time)


                    
#            print('Next bell at: ', bell_sched[bell_count])



    except KeyboardInterrupt:
        print('Ctr-C pressed!')
        print('Returning to main menu')
        mainmenu()
#    except:
#        print('Unhandled program error.....')
#        print('Exiting program........')
#        quit()

#Starting program with mainmenu() function call
mainmenu()
